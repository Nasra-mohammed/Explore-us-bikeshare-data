import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')

    valid_cities = ['chicago', 'new york city', 'washington']
    valid_months = ['all', 'january', 'february', 'march', 'april', 'may', 'june']
    valid_days = ['all', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']

    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    while True:
        city = input('Enter city (Chicago, New York City, Washington): ').lower()
        if city in valid_cities:
            break
        else:
            print('Invalid city. Please choose from Chicago, New York City, or Washington.')

    # get user input for month (all, january, february, ... , june)
    while True:
        month = input('Enter month (all, january, february, ..., june): ').lower()
        if month in valid_months:
            break
        else:
            print('Invalid month. Please choose from the available options.')

    # get user input for day of week (all, monday, tuesday, ... sunday)
    while True:
        day = input('Enter day of the week (all, monday, tuesday, ..., sunday): ').lower()
        if day in valid_days:
            break
        else:
            print('Invalid day. Please choose from the available options.')


    print('-'*40)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """

    filename = CITY_DATA[city]

    # Read file into a Pandas DataFrame
    df = pd.read_csv(filename)

    # Convert the 'Start Time' column to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'])

    # Extract month and day of week from 'Start Time' for filtering
    df['Month'] = df['Start Time'].dt.month
    df['Day of Week'] = df['Start Time'].dt.day_name()

    # Apply month and day filters if they are not set to "all"
    if month != 'all':
        # Use the month index (1 = January, 2 = February, ..., 6 = June)
        month_num = ['january', 'february', 'march', 'april', 'may', 'june'].index(month) + 1
        df = df[df['Month'] == month_num]

    if day != 'all':
        df = df[df['Day of Week'] == day.title()]

    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # Month mapping
    month_mapping = {
        1: 'January',
        2: 'February',
        3: 'March',
        4: 'April',
        5: 'May',
        6: 'June'
    }

    # Display the most common month
    most_common_month = df['Month'].mode()[0]
    print(f"The most common month is {most_common_month}.")

    # Display the most common day of week
    most_common_day = df['Day of Week'].mode()[0]
    print(f"The most common day of the week is {most_common_day}.")

    # Display the most common start hour
    df['Start Hour'] = df['Start Time'].dt.hour
    most_common_hour = df['Start Hour'].mode()[0]
    print(f"The most common hour is {most_common_hour}:00.")


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    most_common_start_station = df['Start Station'].mode()[0]
    print(f"The most common start station is: {most_common_start_station}")

    # display most commonly used end station
    most_common_end_station = df['End Station'].mode()[0]
    print(f"The most common end station is: {most_common_end_station}")

    # Create a new column 'Trip' that combines start and end stations
    df['Trip'] = df['Start Station'] + " to " + df['End Station']

    #display most frequent combination of start station and end station trip
    most_common_trip = df['Trip'].mode()[0]
    print(f"The most common trip is: {most_common_trip}")


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time in hours
    total_travel_time_hours = df['Trip Duration'].sum() / 3600
    print(f"The total travel time is: {total_travel_time_hours:.2f} hours")

    # display mean travel time in minutes
    average_travel_time_minutes = df['Trip Duration'].mean() / 60
    print(f"The average travel time is: {average_travel_time_minutes:.2f} minutes")


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    user_counts = df['User Type'].value_counts()
    print("Counts of each User Type:")
    print(user_counts)

    # Display counts of genderr (if 'Gender' column exists in the city)
    if 'Gender' in df.columns:
        gender_counts = df['Gender'].value_counts()
        print("\nCounts of each Gender:")
        print(gender_counts)

    # Display earliest, most recent, and most common year of birth (if 'Birth Year' column exists in the city)
    if 'Birth Year' in df.columns:
        earliest_birth_year = df['Birth Year'].min()
        most_recent_birth_year = df['Birth Year'].max()
        most_common_birth_year = df['Birth Year'].mode()[0]
        print("\nEarliest Birth Year:", earliest_birth_year)
        print("Most Recent Birth Year:", most_recent_birth_year)
        print("Most Common Birth Year:", most_common_birth_year)


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def display_data(df):
    """
    Displays raw data to the user upon request.

    Args:
        df (DataFrame): Pandas DataFrame containing the bikeshare data.
    """
    pd.set_option('display.max_columns', None)  # Display all columns
    pd.set_option('display.max_rows', None)     # Display all rows
    row_index = 0
    while True:
        show_raw_data = input('\nWould you like to see 5 lines of raw data? Enter yes or no.\n')
        if show_raw_data.lower() != 'yes':
            break

        # Display the next 5 lines of raw data
        print(df.iloc[row_index:row_index + 5])
        row_index += 5

        # Check if there's no more raw data to display
        if row_index >= len(df):
            print("No more raw data to display.")
            break

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)

        display_data(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()
